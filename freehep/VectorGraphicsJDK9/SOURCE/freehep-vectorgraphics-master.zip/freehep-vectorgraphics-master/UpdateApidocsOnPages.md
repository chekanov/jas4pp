To update apidocs on `gh-pages` branch you need to execute:

```
mvn clean 
mvn javadoc:javadoc
mvn scm-publish:publish-scm
```
