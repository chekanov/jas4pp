For information on the FreeHEP VectorGraphics package see:

	http://freehep.github.io/freehep-vectorgraphics

or, checkout the gh-pages branch and run 

	jekyll build

	look into _site/index.html

Mark Donszelmann,
The FreeHEP Team.

