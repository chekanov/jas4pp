TestFiles

ok  [test2] (206 bytes)         End ShowFrame DefineShape PlaceObject SetBackgroundColor PlaceObject2
ok  [button] (562 bytes)        DefineShape2 ButtonRecord
ok  [textbox] (776 bytes)       DefineFont DefineText DefineFontInfo DefineEditText
ok  [test] (2 k)                DefineBits JPEGTables
ok  [firstrun] (2 k)            RemoveObject
ok  [sound3] (4 k)              DefineSound StartSound SoundStreamHead SoundStreamHead2
ok  [profero] (27 k)            DefineButton DoAction Protect RemoveObject2 DefineButton2
ok  [test3] (61 k)              DefineBitsJPEG2
ok  [sound] (148 k)             DefineButtonSound
ok  [lossless] (1993 k)         DefineBitsLossless DefineShape3 DefineText2
ok  [animation] (10 k)
ok  [anim_flash] (11 k)